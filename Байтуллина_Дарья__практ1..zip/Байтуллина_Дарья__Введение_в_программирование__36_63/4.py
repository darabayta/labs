u = input()
print(f'Привет, я {u}')