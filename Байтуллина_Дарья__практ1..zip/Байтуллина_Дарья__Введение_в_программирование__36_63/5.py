u = int(input())
b = int(input())
print(u*b)