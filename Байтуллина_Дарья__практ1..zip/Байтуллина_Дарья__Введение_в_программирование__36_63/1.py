s = input()

n = int(s)
s2 = str(n)

print(type(s))
print(type(n))
print(type(s2))