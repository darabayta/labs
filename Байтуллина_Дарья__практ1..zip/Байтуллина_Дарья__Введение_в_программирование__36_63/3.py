cap = int(input())
on = int(input())
wait = int(input())
if cap< on+wait:
    print(abs(cap - (on+wait)))
else:
    print(0)